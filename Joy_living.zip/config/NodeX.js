const nodeX = require('../middleware/nodeXObj')
let state = new nodeX({
    state: {

    },
    mutations: {

    },
    actives: {

    },
    getters: {

    }
});
module.exports = state