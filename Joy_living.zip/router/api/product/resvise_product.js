const {} = require('../../../controls/product')
module.exports = function (req,res) {
    
}